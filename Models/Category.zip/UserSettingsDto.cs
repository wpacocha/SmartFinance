namespace SmartFinance.API.Models
{
    public class UserSettingsDto
    {
        public string Username { get; set; }
        public string PreferredCurrency { get; set; }
    }
}
