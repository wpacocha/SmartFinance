namespace SmartFinance.API.Models;

public class MonthRecord
{
    
}