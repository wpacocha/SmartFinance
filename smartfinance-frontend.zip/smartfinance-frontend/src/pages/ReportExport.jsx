import { saveAs } from 'file-saver';
import axios from 'axios';
import { toast } from 'react-toastify';

const exportCsvReport = async (month, year) => {
    try {
        const response = await axios.get(`http://localhost:5201/api/report/export?month=${month}&year=${year}`, {
            responseType: 'blob',
        });

        saveAs(response.data, `report_${year}_${month}.csv`);
        toast.success('Raport zosta� wygenerowany!');
    } catch (error) {
        toast.error('B��d podczas generowania raportu.');
    }
};

// W komponencie JSX
<button onClick={() => exportCsvReport(3, 2025)}>Eksportuj raport CSV</button>
