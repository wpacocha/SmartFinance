namespace SmartFinance.API.Controllers;

public class MonthController
{
    
}